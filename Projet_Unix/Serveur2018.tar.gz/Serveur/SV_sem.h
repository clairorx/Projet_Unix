int CreationMutex(void);
int DestructionMutex(int);
int Init_Mutex(int, int);
int P(int, int);
int V(int, int);


