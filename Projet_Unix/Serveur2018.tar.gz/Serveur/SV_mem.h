/************************
** Fichier    SV_mem.h       **
************************/

int AllocMemoireClient(int **);
int AllocTampon(BUF **);
int RelacheMemoires(int , int );
