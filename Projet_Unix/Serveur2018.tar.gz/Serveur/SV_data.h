/************************
** Fichier    SV_data.h       **
************************/

void SignaleDonnee(int, int *);
int GenereData(BUF *, int);
