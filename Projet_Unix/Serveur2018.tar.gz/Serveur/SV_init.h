/************************
**  Fichier    SV_init.h       **
************************/

void Timeout(int);
int GereFichierCle(long *);

